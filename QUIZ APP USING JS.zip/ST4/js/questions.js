
let questions = [
    {
    numb: 1,
    question: "Javascript is an _______ language?",
    answer: "Object-Oriented",
    options: [
      "Object-Oriented",
      "Object-based",
      "Procedural",
      "None of these"
    ]
  },
    {
    numb: 2,
    question: "Which of the following methods is used to access HTML elements using Javascript?",
    answer: "Both A and B",
    options: [
      "getElementbyId()",
      "getElementByClassName()",
      "Both A and B",
      "None of the above"
    ]
  },
    {
    numb: 3,
    question: "Which function is used to serialize an object into a JSON string in Javascript?",
    answer: "stringify()",
    options: [
      "parse()",
      "stringify()",
      "convert()",
      "None of the above"
    ]
  },
    {
    numb: 4,
    question: "Which of the following is not a Javascript framework?",
    answer: "Cassandra",
    options: [
      "Node",
      "Vue",
      "React",
      "Cassandra"
    ]
  },
    {
    numb: 5,
    question: "In JavaScript the x===y statement implies that:",
    answer: "Both are equal in the value and data type",
    options: [
      "Both x and y are equal in value, type and reference address as well",
      "Both are x and y are equal in value only",
      "Both are equal in the value and data type",
      "Both are not same at all"
    ]
  },
  

     {
     numb: 6,
     question: "Choose the correct snippet from the following to check if the variable 'a' is not equal the 'NULL':",
     answer: "if(a!==null)",
     options: [
       "if(a!==null)",
       "if (a!)",
       "if(a!null)",
       "if(a!=null)"
     ]
   },
   {
    numb: 7,
    question: "Which property is used to define the HTML content to an HTML element with a specific id?",
    answer: "innerHTML",
    options: [
      "innerText",
      "innerContent",
      "innerHTML",
      "elementText"
    ]
  },

   {
    numb: 8,
    question: "In JavaScript, single line comment begins with _______.",
    answer: "//",
    options: [
      "#",
      "/*",
      "$",
      "//"
    ]
  },
  {
    numb: 9,
    question: "What is the default value of an uninitialized variable?",
    answer: "undefined",
    options: [
      "0",
      "undefined",
      "null",
      "NaN"
    ]
  },
  {
    numb: 10,
    question: "JavaScript arrays are written with _______.",
    answer: "square brackets []",
    options: [
      "round brackets ()",
      "single quotes '' ",
      "curly brackets {}",
      "square brackets []"
    ]
  },

];